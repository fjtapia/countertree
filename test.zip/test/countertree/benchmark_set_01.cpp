///----------------------------------------------------------------------------
// FILE : benchmark_set_01.cpp
//
// DESCRIPTION : This program is for to compare the speed of the std::set
//  with the countertree::set, and std::multiset with countertree::multiset
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#include <iostream>
#include <stdlib.h>
#include <time.h>

#include <set>
#include <boost/countertree/forest/set.hpp>
#include <boost/countertree/alloc/suballocator.hpp>

#define NELEM 30000000

using std::cout ;
using std::cin;
using std::endl;

uint64_t A[NELEM];
template <typename  T> void Prueba ( T &T1) ;

template <typename  T> int Conjunto ( void ) ;

int  main ( void)
{   //---------------------- Variables----------------------------

    //--------------------------------------------------------------
    //                  P R U E B A S
    //--------------------------------------------------------------
    typedef std::set <uint64_t> S1 ;
    typedef std::multiset<uint64_t> MS1 ;
    typedef countertree::forest::set<uint64_t> CS1 ;
    typedef countertree::forest::multiset<uint64_t> CMS1 ;
    //typedef countertree::forest::set<uint64_t,false,  std::less<uint64_t>, countertree::alloc::suballocator<void> > CSP1 ;
    //typedef countertree::forest::multiset<uint64_t,false,  std::less<uint64_t>, countertree::alloc::suballocator<void> > CMSP1 ;
    //--------------------------------------------------------------
    //                  P R U E B A S
    //--------------------------------------------------------------
    uint32_t Option =0 ;

    cout<<"                 MENU   \n";
    cout<<"               ======== \n";
    cout<<"1.-std::set-------------------------->\n";
    cout<<"2.-std::multiset--------------------->\n";
    cout<<"3.-countertree::set------------------>\n";
    cout<<"4.-countertree::multiset------------->\n";
    cout<<"5.-countertree::set_pool------------->\n";
    cout<<"6.-countertree::multiset_pool-------->\n";
    cout<<"7.- EXIT\n\n";
    cout<<"Select Option ->";
    cin>>Option ;
    switch ( Option)
    {
    case 1: cout<<"std::set     ------------------------------------------->\n";
            Conjunto<S1 > () ;
            break ;

    case 2: cout<<"std::multiset-------------------------------------------->\n";
            Conjunto<MS1 > () ;
            break ;

    case 3: cout<<"countertree::set -------------------------------------------->\n";
            Conjunto<CS1 > () ;
            break ;

    case 4: cout<<"countertree::multiset-------------------------------------------->\n";
            Conjunto<CMS1 > () ;
            break ;
/*
    case 5: cout<<"countertree::set_pool------------------------------------------->\n";
            Conjunto<CSP1 > () ;
            break;

    case 6: cout<<"countertree::multiset_pool--------------------------------------->\n";
            Conjunto<CMSP1 > () ;
            break;
*/
    default: break;

    };
    return 0 ;
};
template <typename  T>
int  Conjunto ( void)
{   //---------------------- Variables----------------------------
    T T1;
    int i ;
    //------------------------ Inicio -----------------------------
    for (  i = 0 ; i < NELEM; i ++ )
    {    T1.insert( i);
    };
    cout<<(system ( "ps -C benchmark_set_01 -o size "))<<endl;
    T1.clear();

    cout<<"----------Insertion of "<< NELEM<<" elements---------\n" ;
    cout<<"Many elements , sorted elements\n";
    for ( i = 0 ; i < NELEM ; i ++)
        A[i] = NELEM +i ;
    Prueba<T>(T1) ;

    cout<<"Many elements , few repeated\n";
    for ( i = 0 ; i < NELEM  ; i ++)
        A[i] = ((rand()%65000) *(rand() %65000) + (rand()%65000)) ;
    Prueba<T>(T1) ;

    cout<<"Many elements , quite repeated\n";
    for ( i = 0 ; i < NELEM  ; i ++)
        A[i] = ((rand()%65000) *(rand() %65000) + (rand()%65000))  % (NELEM/2);
    Prueba<T>(T1) ;

    cout<<"Many element many repeated\n";
    for ( i = 0 ; i < NELEM  ; i ++)
        A[i] = rand() %10000;
    Prueba<T>(T1) ;

    cout<<"Equal elements\n";
    for ( i = 0 ; i < NELEM  ; i ++)
        A[i] = NELEM;
    Prueba<T>(T1) ;
    cout<<(system ( "ps -C benchmark_set_01 -o size "))<<endl;
    return 0 ;
};

template <typename  T>
void Prueba ( T & M1 )
{   //----------------------------- Inicio ------------------------
    double duracion ;
	clock_t start, finish;

    // ----------------------------------------
    start = clock();
    for ( int i = 0 ; i < NELEM; i ++ )
    {    M1.insert( A[i] );
    };
    finish = clock() ;
    M1.clear();
    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";

    cout<<"---------------------------------------------------\n";
};

