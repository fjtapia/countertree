//----------------------------------------------------------------------------
/// @file test_set.cpp
/// @brief Test program of the classes countertree::set and countertree::multiset
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#define __DEBUG_CNTREE 1
#include <boost/countertree/myallocator.hpp>

#include <boost/countertree/set.hpp>
#include <iostream>

#define NELEM   1000000
int V[NELEM];


namespace cntree = countertree ;

struct counter
{   int N ;
    counter ( void):N(-1){};
    counter ( int K):N(K){};
    counter ( const counter &c):N( c.N){};
    counter ( counter &&c):N(c.N) { c.N = -1;};
    counter & operator = ( const counter &c)
    {   N = c.N;
        return *this ;
    };
    counter & operator = ( counter &&c)
    {   N = c.N;
        c.N = -1;
        return *this ;
    };

    bool operator < ( const counter & c)const  { return ( this->N < c.N) ;};
    bool operator > ( const counter & c)const  { return ( this->N > c.N) ;};
};

int main ()
{   //---------------------------- begin -------------------------
/*
    cntree::set_cnc<int >  S1,S2 ;
    auto M1 = [] ( const int & k)->bool{ return ((k&1) == 0 );};

    // ---------- insert_if ----------------------
    for ( int i = 0 ; i < 100 ; ++i)
        S1.insert ( i);

    assert ( S1.size() == 100);
    for ( int i = 0 ; i < 100 ; ++i)
        assert ( S1.pos(i)  == i );
    S2.insert ( S1.begin(), S1.end() );
    assert ( S2.size() == 100);
    for ( int i = 0 ; i < 100 ; ++i)
        assert ( S2.pos(i)  == i );
    S2.clear() ;

    S2.insert_if ( S1.begin(), S1.end() , M1);
    assert ( S2.size() == 50);
    for ( int i = 0 ; i < 50 ; ++i)
        assert ( S2.pos(i)  == (i *2));

    S1.clear() ;
    S2.clear() ;

    for ( int i = 0 ; i < 100 ; ++i)
        S1.insert_if ( M1,i);
    assert ( S1.size() == 50);
    for ( int i = 0 ; i < 50 ; ++i)
        assert ( S1.pos(i)  == (i *2));

    S1.clear() ;
    S2.clear() ;

    for ( int i = 0 ; i < 100 ; ++i)
        S1.insert ( i);
    S1.pop_front() ;
    S1.pop_back() ;

    assert ( S1.size() == 98);
    for ( int i = 0 ; i < 98 ; ++i)
        assert ( S1.pos(i)  == i+1 );

    S1.clear() ;
    for ( int i = 0 ; i < 100 ; ++i)
        S1.insert ( i);
    S2 = S1 ;
    S1.erase ( S1.begin()+50);
    assert ( S1.pos(50) == 51);
    S1 = S2 ;
    S2.erase_if(S2.begin() +50, M1 );
    S2.erase_if(S2.begin() +49, M1 );
    assert ( S2.pos(49) == 49)  ;
    assert ( S2.pos(50) == 51)  ;
    S2 = S1 ;
    S1.erase_pos( 50);
    assert ( S1.pos(50)== 51 );
    S1 = S2 ;
    S1.erase_pos_if (50, M1 );
    S1.erase_pos_if (49, M1 );
    assert ( S1.pos(49) == 49)  ;
    assert ( S1.pos(50) == 51)  ;

    S1 = S2 ;
    S1.erase ( S1.begin() , S1.const_iterator_pos (50));
    assert ( S1.size() == 50);
    for ( int i = 0 ; i < 50 ; ++i)
        assert ( S1.pos(i)  == (i+ 50));

    S1 = S2 ;
    S1.erase_if ( S1.begin() , S1.end(), M1);
    assert ( S1.size() == 50);
    for ( int i = 0 ; i < 50 ; ++i)
        assert ( S1.pos(i)  == (i*2)+1);

    S1 = S2 ;
    S1.erase_pos ( 0 , 50);
    assert ( S1.size() == 50);
    for ( int i = 0 ; i < 50 ; ++i)
        assert ( S1.pos(i)  == (i+ 50));
    S1 = S2 ;
    S1.erase_pos_if ( 0 , 100, M1);
    for ( int i = 0 ; i < 50 ; ++i)
        assert ( S1.pos(i)  == (i*2)+1);

    S1 = S2 ;
    S1.erase ( 50);
    assert ( S1.pos(50) == 51 );

    S1 = S2 ;
    S1.erase_if (50, M1 );
    S1.erase_if (49, M1 );
    assert ( S1.pos(49) == 49)  ;
    assert ( S1.pos(50) == 51)  ;
*/

    //---------------- rvalues --------------------
    //cntree::set <counter, std::less<counter>, c_common::myallocator<void,false> > S3,S4 ;
    cntree::set <counter > S3,S4 ;
    for ( int i =0 ; i < 100 ; ++i)
    {   counter C3 ( i);
        S3.insert ( std::move(C3) );
        assert ( C3.N == -1);
    }

    assert ( S3.size() == 100);
    for ( int i = 0 ; i < 100 ; ++i)
        assert ( S3.pos(i).N  == i );
    S3.clear() ;

    auto M2 = [] ( const counter & k)->bool{ return ((k.N&1) == 0 );};
    for ( int i =0 ; i < 100 ; ++i)
    {   counter C3 ( i);
        S3.insert_if (M2, std::move(C3) );
    }
    assert ( S3.size() == 50);
    for ( int i = 0 ; i < 50 ; ++i)
        assert ( S3.pos(i).N  == (i *2));
    S3.clear();

    for ( int i =0 ; i < 100 ; ++i)
        S3.insert( counter(i));
    assert ( S3.size() == 100);

    S4.insert_if  ( S3.begin(), S3.end() , M2);
    assert ( S4.size() == 50);
    for ( int i = 0 ; i < 50 ; ++i)
        assert ( S4.pos(i).N  == (i *2));
    S3.clear() ;
    for ( int i =0 ; i < 100 ; ++i)
        S3.emplace( i);
    assert ( S3.size() == 100);
    for ( int i = 0 ; i < 100 ; ++i)
        assert ( S3.pos(i).N  == i );

    S3.clear() ;
    for ( int i =0 ; i < 100 ; ++i)
        S3.emplace_if(M2, i);

    assert ( S3.size() == 50);
    for ( int i = 0 ; i < 50 ; ++i)
        assert ( S3.pos(i).N  == (i *2));

    return 0 ;
};
