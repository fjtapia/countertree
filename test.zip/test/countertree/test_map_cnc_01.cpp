///----------------------------------------------------------------------------
// FILE : Benchmark_set.cpp
//
// DESCRIPTION : This program is for to compare the speed of the std::set
//  with the countertree::set, and std::multiset with countertree::multiset
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <thread>
#include <atomic>


#include <boost/countertree/map.hpp>


#define NELEM 1000000
namespace cntree= countertree;
using std::cout ;
using std::cin;
using std::endl;

uint32_t Primo [ 10000], Primo2[10000] ;
uint32_t NPrimo ;
uint32_t *A;
typedef cntree::map_cnc <uint32_t , std::atomic_uint > mymap ;
typedef typename mymap::value_type             value_type ;
typedef typename mymap::iterator             iterator ;
typedef typename mymap::mapped_type             data_t ;

static const uint32_t HC = std::thread::hardware_concurrency() ;

static const uint32_t NCores = (HC > 8)?8:HC;
//static const uint32_t NCores = 1 ;
void Count2  ( mymap & M , uint32_t PosIni, uint32_t NElem );
void Generation ( void)
{	//------------------ Definición de constantes------------
    Primo[0] = 2 ;
    Primo[1] = 3 ;
    Primo[2] = 5;
    Primo[3] = 7;
    Primo[4] = 11;
    Primo[5] = 13 ;
    NPrimo = 6 ;

    uint64_t Tope =2, Tope2 = 25;

    for ( uint32_t Num = 17 ; Num < 65536 ; Num+=2)
    {   bool EsPrimo = true ;
        if ( Num >= Tope2)
        {   Tope++ ;
            Tope2 = Primo[Tope ]* Primo[Tope];
        };
        for ( uint32_t k = 1 ; k < Tope and EsPrimo; ++k)
        {   if (  ( Num % Primo[k]) == 0 ) EsPrimo = false ;
        };
        if (EsPrimo) Primo [ NPrimo++] = Num;
    };
    for ( uint32_t i = 0 ; i < NPrimo ; ++i)
        Primo2[i] = Primo[i]* Primo[i];
};
int  main ( void)
{   //---------------------- Variables----------------------------
    Generation();
    A = new uint32_t [NELEM];
    for ( uint32_t i = 0 ; i < NELEM ; ++i)
        A[i] = rand();

    //--------------------------------------------------------------
    uint32_t Ini[8], N[8];
    mymap  M ;
    std::thread T [8];

    uint32_t Cupo = NELEM / NCores ;
    for ( uint32_t  i =0 ; i < NCores ; ++i)
    {   Ini[i] = i * Cupo ;
        N[i] =  ( (i * Cupo)> NELEM)? NELEM - ( (i-1)* Cupo) : Cupo ;
        std::cout<<"["<<Ini[i]<<" , "<<N[i]<<" ]\n";
    };

    //Count2 (M, 0, NELEM);

    double duracion ;
	clock_t start, finish;
	start = clock() ;

    for ( uint32_t  i =0 ; i < NCores ; ++i)
    {   T[i] = std::thread ( Count2, std::ref(M), Ini[i], N[i] );
    };
    for ( uint32_t  i =0 ; i < NCores ; ++i)
    {   T[i].join();
    };
    finish = clock() ;

    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";
    cout<<(system ( "ps -C test_map_cnc_01 -o rss"))<<endl;

    M.clear();
    cout<<"---------------------------------------------------\n";


    delete[] A;
    cout<<(system ( "ps -C test_map_cnc_01 -o rss"))<<endl;
    return 0 ;
};
void Count2  ( mymap & M , uint32_t PosIni, uint32_t NElem )
{   //----------------------------- Inicio ------------------------
    const uint32_t PosEnd = PosIni + NElem ;
    std::cout<<" Inicio Tarea "<<PosIni<<" - "<<NElem<<std::endl;
    //auto L1 = [] ( value_type & K)->void{ K.second++;};
    std::piecewise_construct_t XXX ;
    std::pair <mymap::iterator, bool> Delta ;
    for ( uint32_t i = PosIni ; i < PosEnd; ++i  )
    {   bool EsPrimo = true ;
        uint32_t N = A[i];
        for (uint32_t k = 0 ; N >= Primo2[k] and EsPrimo; ++k)
        {   if ( (N%Primo[k]) == 0)
            {   N = N / Primo[k];
                Delta.first = M.find( Primo[k]);
                if ( Delta.first == M.end())
                {   Delta = M.emplace (   XXX, std::tuple<int>(Primo[k]), std::tuple<int>( 0)   );
                };
                Delta.first->second++ ;
            };
        };
        Delta.first = M.find( N);
        if ( Delta.first == M.end())
        {   Delta = M.emplace (   XXX, std::tuple<int>(N), std::tuple<int>( 0)   );
        };
        Delta.first->second++ ;
    };


    //{   M.insert_or_modify ( A[i], 1, std::ref(L1));
    //    //(M[ A[i]])++;
    //};
    cout<<"---------------------------------------------------\n";

};



