//----------------------------------------------------------------------------
/// @file bjam_singleton.cpp
/// @brief Test program of the class singleton
///
/// @author Copyright (c) 2010 2012 Francisco Jose Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#define __DEBUG_CNTREE 1

#include <boost/countertree/common/singleton.hpp>
#include <cassert>
#include <thread>
#include <iostream>


namespace c_common = countertree::common ;

struct chapuza
{   int N ;
    ~chapuza () { N =0 ;};
};


void prueba ( void)
{   //---------------------- begin ---------------------
    chapuza & ch = c_common::singleton<chapuza>::instance() ;
    std::cout<<"Antes  "<<ch.N<<std::endl;
    ch.N = 17 ;
    std::cout<<"Despues  "<<ch.N<<std::endl;
    std::cout<"Chapuza creada y modificada\n";

}

int main ( void)
{
    std::thread T1 ( prueba);
    T1.join() ;
    std::thread T2 ( prueba);


    T2.join() ;
}
