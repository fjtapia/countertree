//----------------------------------------------------------------------------
/// @file test_global_alloc_cnc.cpp
/// @brief Test program of the class golbal_alloc_cnc
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#include <boost/countertree/common/global_alloc_cnc.hpp>
#include <iostream>

#define NELEM_VECTOR 10000000


namespace cntr_alloc= countertree::common ;


int main ( void)
{   //---------------------------- begin---------------------------
    void * P1 = cntr_alloc::glb.allocate ( 4 );
    int * Alfa = static_cast <int*> ( P1);
    *Alfa = 17 ;
    std::cout<< ( *Alfa)<<std::endl;
    cntr_alloc::glb.deallocate ( P1 );

    return 0 ;

}
