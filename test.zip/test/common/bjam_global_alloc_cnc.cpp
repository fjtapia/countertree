//----------------------------------------------------------------------------
/// @file bjam_global_alloc_cnc.cpp
/// @brief Test program of the class golbal_alloc_cnc
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#define __DEBUG_CNTREE 1
#include <boost/test/included/unit_test.hpp>
#include <boost/countertree/common/global_alloc_cnc.hpp>
#include <iostream>

using namespace boost::unit_test;
namespace cntr_alloc= countertree::common ;


void prueba ( void)
{   //---------------------------- begin---------------------------
    void * P1 = cntr_alloc::glb.allocate ( 1024 );
    int32_t * Alfa = static_cast <int32_t*> ( P1);
    for ( int32_t i =0 ; i < 256 ; ++i)
        Alfa[i] = i ;
    cntr_alloc::glb.deallocate ( P1 );
};

test_suite* init_unit_test_suite( int argc, char* argv[] )
{
    framework::master_test_suite().
        add( BOOST_TEST_CASE( &prueba ) );

    return 0;
}
