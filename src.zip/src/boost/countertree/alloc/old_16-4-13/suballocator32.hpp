//----------------------------------------------------------------------------
/// @file suballocator32.hpp
/// @brief
///
/// @author Copyright (c) 2010 2013 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_SUBALLOCATOR32_HPP
#define __CNTREE_SUBALLOCATOR32_HPP

#include <boost/countertree/alloc/basic_suballoc32.hpp>
#include <boost/countertree/alloc/filter_suballoc.hpp>
#include <limits>

namespace countertree
{
namespace alloc
{
using countertree::common::myallocator ;
//##########################################################################
//                                                                        ##
//           C L A S S         S U B A L L O C A T O R 3 2                ##
//                                                                        ##
//##########################################################################
//-------------------------------------------------------------
/// @class suballocator32
///
/// @remarks This class is an allocator with a incremental pool
///          of alogaritmic number of elements
//----------------------------------------------------------------
template    <   bool cnc = false ,
                typename Allocator = myallocator<void,cnc>
            >
class suballocator32 :
public basic_suballoc32 < typename filter_suballoc<Allocator>::name,
                          cnc,
                          typename Allocator::value_type
                        >
{
public :
//***************************************************************************
//                  D E F I N I T I O N S
//***************************************************************************
typedef typename filter_suballoc<Allocator>::name   MyAllocator ;
typedef typename MyAllocator::value_type            value_type ;

typedef basic_suballoc32
<   typename filter_suballoc<Allocator>::name,
    cnc,
    typename Allocator::value_type
> mybasic_suballoc32 ;

//***************************************************************************
//  C O N S T R U C T O R S , D E S T R U C T O R S , R E B I N D
//
//  explicit suballocator32() ;
//  suballocator32( suballocator32<Allocator> const&) ;
//
//  template<typename U>
//  suballocator32(suballocator32<U> const&) ;
//
//  virtual ~suballocator32() ;
//
//  template<typename U>
//  struct rebind
//
//***************************************************************************
//------------------------------------------------------------------------
//  function : suballocator32
/// @brief constructor of the class
//------------------------------------------------------------------------
explicit suballocator32 ( void ) { };
//------------------------------------------------------------------------
//  function : suballocator32
/// @brief constructor of the class
//------------------------------------------------------------------------
suballocator32 ( const Allocator &Alfa ):mybasic_suballoc32(Alfa) { };
//------------------------------------------------------------------------
//  function : suballocator32
/// @brief Copy constructor
/// @param [in] Alfa : this parameter is passed to the basic_suballocator
//------------------------------------------------------------------------
suballocator32 ( const suballocator32 &Alfa ):mybasic_suballoc32 (Alfa) { };
//------------------------------------------------------------------------
//  function : suballocator32
/// @brief Copy constructor fron an allocator of other type
/// @param [in] The parameter is not used
//------------------------------------------------------------------------
template<bool cnc2,typename U>
suballocator32(suballocator32<cnc2,U> const&) {};
//------------------------------------------------------------------------
//  function : ~basic_suballoc32
/// @brief Destructor of the class
//------------------------------------------------------------------------
virtual ~suballocator32() { };
//--------------------------------------------------------------------------
//    convert an allocator<T> to allocator<U>
//--------------------------------------------------------------------------
template<typename U>
struct rebind
{   typedef  typename MyAllocator::template rebind<U>::other base_other ;
    typedef suballocator32 <cnc, base_other> other;
};
//***************************************************************************
//           B O O L E A N    O P E R A T O R S
//
//  bool operator==(suballocator32 const&) ;
//  bool operator!=(suballocator32 const& ) ;
//
//  template <typename Allocator2>
//  bool operator==(suballocator32<Allocator2> const&)
//
//  template <typename Allocator2>
//  bool operator!=(suballocator32<Allocator2> const& )
//
//***************************************************************************
//------------------------------------------------------------------------
//  function : operator==
/// @brief equality operator
/// @param [in] reference to the suballocator to compare
/// @return always return true
/// @remarks
//------------------------------------------------------------------------
bool operator==(suballocator32 const&) {  return true; };
//------------------------------------------------------------------------
//  function : operator !=
/// @brief inequality operator
/// @param [in]reference to the suballocator to compare
/// @return always return false
/// @remarks
//------------------------------------------------------------------------
bool operator!=(suballocator32 const& )  {   return false;  };
//------------------------------------------------------------------------
//  function : operator==
/// @brief equality operator
/// @param [in] reference to the suballocator to compare
/// @return always return true
/// @remarks
//------------------------------------------------------------------------
template <bool cnc2,typename Allocator2>
bool operator==(suballocator32<cnc2,Allocator2> const&)  { return true; };
//------------------------------------------------------------------------
//  function : operator !=
/// @brief inequality operator
/// @param [in]reference to the suballocator to compare
/// @return always return false
/// @remarks
//------------------------------------------------------------------------
template <bool cnc2,typename Allocator2>
bool operator!=(suballocator32<cnc2,Allocator2> const& ) { return false; };
//***************************************************************************
};//        E N D     S U B A L L O C A T O R 3 2      C L A S S
//***************************************************************************

//***************************************************************************
};};//     E N D    A L L O C   &   C N T R E E    N A M E S P A C E
//***************************************************************************
#endif
