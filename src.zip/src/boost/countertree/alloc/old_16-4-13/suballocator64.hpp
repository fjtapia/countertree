//----------------------------------------------------------------------------
/// @file suballocator64.hpp
/// @brief
///
/// @author Copyright (c) 2010 2013 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_SUBALLOCATOR64_HPP
#define __CNTREE_SUBALLOCATOR64_HPP

#include <boost/countertree/alloc/basic_suballoc64.hpp>
#include <boost/countertree/alloc/filter_suballoc.hpp>
#include <limits>

namespace countertree
{
namespace alloc
{
using countertree::common::myallocator ;
//##########################################################################
//                                                                        ##
//         C L A S S            S U B A L L O C A T O R 6 4               ##
//                                                                        ##
//##########################################################################
//-------------------------------------------------------------
/// @class suballocator64
///
/// @remarks This class is an allocator with a incremental pool
///          of alogaritmic number of elements
//----------------------------------------------------------------
template    <   bool cnc = false ,
                typename Allocator = myallocator<uint8_t,cnc>
            >
class suballocator64 :
public basic_suballoc64 < typename filter_suballoc<Allocator>::name ,
                          cnc,
                          typename Allocator::value_type
                        >
{
public :
//***************************************************************************
//                  D E F I N I T I O N S
//***************************************************************************
typedef typename filter_suballoc<Allocator>::name   MyAllocator ;
typedef typename MyAllocator::value_type            value_type ;
typedef basic_suballoc64
<   typename filter_suballoc<Allocator>::name,
    cnc,
    typename Allocator::value_type
> mybasic_suballoc64 ;

//***************************************************************************
//       C O N S T R U C T O R , D E S T R U C T O R , B I N D
//
//  explicit suballocator64();
//  suballocator64( suballocator64<Allocator> const&) ;
//
//  template<typename U>
//  suballocator64(suballocator64<U> const&) ;
//
//  virtual ~suballocator64() ;
//
//  template<typename U>
//  struct rebind
//
//***************************************************************************
//------------------------------------------------------------------------
//  function : basic_suballoc64
/// @brief constructor of the class
//------------------------------------------------------------------------
explicit suballocator64 ( void ) { };
//------------------------------------------------------------------------
//  function : basic_suballoc64
/// @brief constructor of the class
//------------------------------------------------------------------------
suballocator64 ( const Allocator &Alfa ):mybasic_suballoc64 (Alfa) { };
//------------------------------------------------------------------------
//  function : basic_suballoc64
/// @brief Copy constructor
/// @param [in] Alfa : this parameter is passed to the basic_suballocator
//------------------------------------------------------------------------
suballocator64 ( const suballocator64 &Alfa ):mybasic_suballoc64 (Alfa) { };
//------------------------------------------------------------------------
//  function : basic_suballoc64
/// @brief Copy constructor fron an allocator of other type
/// @param [in] The parameter is not used
//------------------------------------------------------------------------
template<bool cnc2,typename U>
suballocator64(suballocator64<cnc2, U> const&) {};
//------------------------------------------------------------------------
//  function : ~basic_suballoc64
/// @brief Destructor of the class
//------------------------------------------------------------------------
virtual ~suballocator64() { };
//--------------------------------------------------------------------------
//    convert an allocator<T> to allocator<U>
//--------------------------------------------------------------------------
template< typename U>
struct rebind
{   typedef  typename MyAllocator::template rebind<U>::other base_other ;
    typedef suballocator64 <cnc,base_other> other;
};

//***************************************************************************
//           B O O L E A N    O P E R A T O R S
//
//  bool operator==(suballocator64 const&)
//  bool operator!=(suballocator64 const& )
//
//  template <typename Allocator2>
//  bool operator==(suballocator64<Allocator2> const&)
//
//  template <typename Allocator2 >
//  bool operator!=(suballocator64<Allocator2> const& )
//
//***************************************************************************
//------------------------------------------------------------------------
//  function : operator==
/// @brief equality operator
/// @param [in] reference to the suballocator to compare
/// @return always return true
/// @remarks
//------------------------------------------------------------------------
bool operator==(suballocator64 const&)  {  return true;   };
//------------------------------------------------------------------------
//  function : operator !=
/// @brief inequality operator
/// @param [in]reference to the suballocator to compare
/// @return always return false
/// @remarks
//------------------------------------------------------------------------
bool operator!=(suballocator64 const& )  { return false;  };
//------------------------------------------------------------------------
//  function : operator==
/// @brief equality operator
/// @param [in] reference to the suballocator to compare
/// @return always return true
/// @remarks
//------------------------------------------------------------------------
template <bool cnc2, typename Allocator2>
bool operator==(suballocator64<cnc2,Allocator2> const&) { return true;  };
//------------------------------------------------------------------------
//  function : operator !=
/// @brief inequality operator
/// @param [in]reference to the suballocator to compare
/// @return always return false
/// @remarks
//------------------------------------------------------------------------
template <bool cnc2,typename Allocator2>
bool operator!=(suballocator64<cnc2,Allocator2> const& )  { return false; };

//***************************************************************************
};//        E N D     S U B A L L O C A T O R 6 4      C L A S S
//***************************************************************************
//***************************************************************************
};};//         E N D    A L L O C   &   C N T R E E    N A M E S P A C E
//***************************************************************************
#endif
