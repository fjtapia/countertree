//----------------------------------------------------------------------------
/// @file   pool64.hpp
/// @brief  This file contains the implementation of the non contiguous memory
///         vector formed with blocks of different size
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_ALLOC_POOL64_CNC_HPP
#define __CNTREE_ALLOC_POOL64_CNC_HPP

#include <boost/countertree/alloc/pool64.hpp>
#include <boost/countertree/common/spinlock.hpp>
#include <boost/countertree/common/allocator_cnc.hpp>
#include <mutex>

namespace cnt_alloc = countertree::alloc ;
namespace countertree
{
namespace alloc
{

//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                    C L A S S                     #             ##
//       #                                                  #             ##
//       #                 P O O L 6 4 _ M C                #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################

//-------------------------------------------------------------
/// @class  pool64_cnc
/// @brief  This class represent a vector of pointers to rows with
///         crescend size
//
/// @remarks
//----------------------------------------------------------------
template <uint64_t SizeElem,  typename AllocByte >
class pool64_cnc
{
public:
//##########################################################################
//                                                                        ##
//     D E F I N I T I O N S    &     S T A T I C _ A S S E R T           ##
//                                                                        ##
//##########################################################################

static const uint64_t MaxElemRow = ( MAX64 >> 1 ) / SizeElem ;
typedef typename AllocByte::value_type	    value_type; //Element type
typedef typename AllocByte::pointer	        pointer; //Pointer to element
typedef typename AllocByte::reference	    reference; //Reference to element
typedef typename AllocByte::const_pointer	const_pointer; //Constant pointer to element
typedef typename AllocByte::const_reference  const_reference; //Constant reference to element
typedef typename AllocByte::size_type		size_type; //Quantities of elements
typedef typename AllocByte::difference_type  difference_type ; //Difference between pointers

static uint64_t const MaskPos = (1ULL << 58)-1 ;
static_assert(sizeof(value_type) == 1,"Error AllocByte");
static_assert( SizeElem != 0 , "Error in SizeElem") ;
static const uint64_t Power2Max =  n_bits_max - NBits64<SizeElem>::N ;
typedef countertree::alloc::spinlock            spinlock ;

private:
//##########################################################################
//                                                                        ##
//                P R I V A T E        V A R I A B L E S                  ##
//                                                                        ##
//##########################################################################

basic_heap64<AllocByte> * V[Power2Max];
uint8_t* Ptr [Power2Max] [2];
AllocByte AB ;

std::atomic<uint64_t> NMax, NElem ;
uint64_t NRow, Mask, Cursor;
spinlock spl;

//##########################################################################
//                                                                        ##
//                 F O R B I D D E N    F U N C T I O N S                 ##
//                                                                        ##
//  pool64 ( const pool64 &);                                             ##
//  pool64 & operator = ( const pool64 &);                                ##
//                                                                        ##
//##########################################################################
explicit pool64_cnc ( const pool64_cnc &) = delete;
pool64_cnc & operator = ( const pool64_cnc &) = delete;

//##########################################################################
//                                                                        ##
//         P R I V A T E      F U N C T I O N S                           ##
//                                                                        ##
//  void create_row (void);                                               ##
//  void delete_row (void)                                                ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : create_row
/// @brief create a new row with double size than the previous
/// @remarks
//------------------------------------------------------------------------
void create_row (void)
{   //--------------begin------------------------------------
    if ( NRow == Power2Max )throw std::bad_alloc();

    V[NRow]= NULL ;
    if (NRow==0)
    {   void * PAux = AB.allocate ( sizeof (heap64<0,AllocByte> ));
        if ( PAux== NULL ) throw std::bad_alloc();
        new ((void*)PAux) heap64 < 0,AllocByte>;
        V[0]= ( basic_heap64<AllocByte> *) PAux ;
    }
    else V[NRow] =V[NRow-1]->create_son(AB);

    ResetBit64 ( Mask , NRow);
    NMax += V[NRow]->capacity();

    Ptr[NRow][0] = NULL;
    Ptr[NRow][0] =  AB.allocate ( V[NRow]->NElemMax * SizeElem );
    if ( Ptr[NRow][0] == NULL )
    {   AB.deallocate ( (uint8_t*)V[NRow],V[NRow]->SIZEOF() );
        V[NRow ] = NULL ;
        throw std::bad_alloc();
    };
    Ptr[NRow][1] = Ptr[NRow][0] + (V[NRow]->NElemMax * SizeElem) ;
    NRow ++ ;
};
//------------------------------------------------------------------------
//  function : delete_row
/// @brief delete the last row
/// @remarks
//------------------------------------------------------------------------
void delete_row (void)
{   //--------------------------------- begin ---------------------------
    while ((NRow >1) and NElem<=((NMax+1)>>2) and (V[NRow-1]->is_empty()))
    {   NRow -- ;
        NMax -= V[NRow]->capacity();
        AB.deallocate ( (uint8_t*)Ptr[NRow][0], V[NRow]->NElemMax * SizeElem);
        AB.deallocate ((uint8_t*)V[NRow], V[NRow]->SIZEOF() );
        V[NRow ] = NULL ;

        Ptr[NRow][0] = Ptr[NRow][1] = NULL ;
        if ( Cursor >= NRow) Cursor = NRow -1 ;
        SetBit64( Mask ,NRow);
    };
};
public:
//##########################################################################
//                                                                        ##
//                P U B L I C      F U N C T I O N S                      ##
//                                                                        ##
//  pool64  ( void)                                                       ##
//  virtual ~pool64 ( void )                                              ##
//                                                                        ##
//  uint64_t     size( void)                                              ##
//  uint64_t     capacity ( void)                                         ##
//  void         clear ( void )                                           ##
//                                                                        ##
//  void * allocate ( void )                                              ##
//  void deallocate ( void *P1)                                           ##
//                                                                        ##
// #if __DEBUG_CNTREE != 0                                                ##
//    bool check( void) const;                                            ##
// #endif                                                                 ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : pool
/// @brief class constructor
/// @remarks
//------------------------------------------------------------------------
pool64_cnc  ( void): NMax(0),NElem(0),NRow(0),Mask(MAX64), Cursor(0)
{   //--------------------------- begin -------------------------
    std::unique_lock<spinlock> ul( spl);
    for ( uint64_t i = 0 ; i < Power2Max ; ++i)
    {   Ptr[i][0]= Ptr[i][1] = NULL ;
        V[i] = NULL;
    };
} ;

//------------------------------------------------------------------------
//  function : ~pool
/// @brief class destructor
/// @remarks
//------------------------------------------------------------------------
virtual ~pool64_cnc ( void ){ clear() ;};

//------------------------------------------------------------------------
//  function : size
/// @brief return the number of elements allocated by the IncVector
/// @return number of elements allocated
/// @remarks
//------------------------------------------------------------------------
uint64_t size( void )const
{   //---------------------- begin ----------------------
    return NElem.load (std::memory_order_consume) ;
};
//------------------------------------------------------------------------
//  function : capacity
/// @brief return the actual capacity of the IncVector
/// @return capacity
/// @remarks
//------------------------------------------------------------------------
uint64_t capacity ( void) const
{   //---------------------------- begin ------------
    return NMax.load (std::memory_order_consume);
};

//------------------------------------------------------------------------
//  function : clear
/// @brief : clean the IncVector
/// @remarks
//------------------------------------------------------------------------
void clear ( void ) ;

//------------------------------------------------------------------------
//  function : allocate
/// @brief Allocate an element from the IncVector
/// @return pointer to the object allocated
/// @remarks
//------------------------------------------------------------------------
void * allocate ( void )
{   //----------------------------------- begin --------------------------
    std::unique_lock<spinlock> ul( spl);
    if ( NElem == NMax) create_row();
    if ( V[Cursor]->is_full())
        Cursor = LS1B_64 (~Mask ) ;
    uint64_t Pos = V[Cursor]->allocate( ) ;
    if ( V[Cursor]->is_full())  SetBit64 (Mask , Cursor);
    NElem ++ ;
    return (Ptr[Cursor][0] + ( Pos * SizeElem)) ;
};
//------------------------------------------------------------------------
//  function : deallocate
/// @brief deallocate an object
/// @param [in]
/// @return
/// @remarks
//------------------------------------------------------------------------
void deallocate ( void *P1)
{   //-------------------------------------- begin --------------------------
    std::unique_lock<spinlock> ul( spl);
    if ( NElem == 0) throw std::bad_alloc();
    bool Found = false ;
    uint64_t i = NRow ;
    uint8_t * PAux = (uint8_t*) P1;
    do
    {   i--;
        Found = (Ptr[i][0]<= PAux and Ptr[i][1]> PAux);
    } while ( not Found and i != 0 )    ;
#if __DEBUG_CNTREE != 0
    if ( not Found)  throw std::bad_alloc();
#endif
    V[i]->deallocate ( (PAux - Ptr[i][0])/SizeElem );
    if ( i < Cursor) Cursor = i ;
    ResetBit64 ( Mask , i );
    NElem -- ;

    if (NElem<=((NMax+1)>>2) and (V[NRow-1]->is_empty()))
        delete_row() ;
};
#if __DEBUG_CNTREE != 0
//------------------------------------------------------------------------
//  function : check
/// @brief check if the internal structure of the pool is OK
/// @param [in]
/// @return  true : correct  false: fail
/// @remarks
//------------------------------------------------------------------------
bool check( void)  ;
#endif

//=========================================================================
};//              E N D     P O O L 6 4     C L A S S
//=========================================================================

//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #        C L A S S    P O O L 6 4                  #             ##
//       #                                                  #             ##
//       #     N O N   I N L I N E    F U N C T I O N S     #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : clear
/// @brief : clean the IncVector
/// @remarks
//------------------------------------------------------------------------
template <uint64_t SizeElem,  typename AllocByte >
void pool64_cnc<SizeElem,AllocByte>::clear ( void )
{   //-------------------------- begin ---------------------
    std::unique_lock<spinlock> ul( spl);
    for ( uint64_t i = 0 ; i < NRow ; ++i)
    {   AB.deallocate ( Ptr[i][0], V[i]->NElemMax * SizeElem);
        Ptr[i][0]= Ptr[i][1] = NULL ;
        AB.deallocate (( uint8_t *) V[i], V[i]->SIZEOF() ) ;
        V[i] = NULL ;
    };
    NElem = NMax = NRow = Cursor= 0 ;
    Mask = MAX64 ;
};

#if __DEBUG_CNTREE != 0
//------------------------------------------------------------------------
//  function : check
/// @brief check if the internal structure of the pool is OK
/// @param [in]
/// @return  true : correct  false: fail
/// @remarks
//------------------------------------------------------------------------
template <uint64_t SizeElem,  typename AllocByte >
bool pool64_cnc<SizeElem,AllocByte>::check( void)
{   //------------------------------ begin -----------------------------
    std::unique_lock<spinlock> ul( spl);
    if ( NElem > NMax or ( ( NElem > 0 or NMax > 0) and NRow == 0 ) )
        std::cout<<"Error en los parametros basicos\n";
    for ( uint64_t i =0 ; i < NRow ; i++)
    {   if ( Ptr[i][0] >= Ptr[i][1] )
        {   std::cout<<"Error en los cachos de memoria\n";
            return false ;
        };
        if ( V[i]->capacity() != ( 1ULL<<i ))
        {   std::cout<<"Pila de un tamaño erroneo\n";
            return false ;
        };
        if ( not V[i]->check() ) return false ;
    };

    return true ;
};
#endif

#if __DEBUG_CNTREE != 0
template < uint64_t SizeElem, typename AllocByte >
std::ostream & operator<< ( std::ostream & S , const pool64_cnc<SizeElem,AllocByte> & P )
{   //--------------------------------------- begin ------------------------

    S<<"Capacity :"<<P.capacity()<<"  Size :"<<P.size() <<std::endl;
    //S<<" Number of rows "<<P.NRow<<std::endl;
    //S<<"Mask of rows filled "<< std::hex<<P.Mask<< std::dec ;
    //S<<"  CursorRow "<<P.Cursor<<std::endl;
    for ( uint64_t i  =0  ; i < P.NRow ; ++i )
    {   S<<"["<<i<<" ] "<< std::hex<<(void*)(P.Ptr[i][0])<<" - "<<(void*)(P.Ptr[i][1]);
        S<< std::dec<< (*P.V[i] );
    };
    return S ;
};
#endif


//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                    C L A S S                     #             ##
//       #                                                  #             ##
//       #       P O O L 6 4 < 0 , A L L O C B Y T E >      #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################

//-------------------------------------------------------------
/// @class  pool64
/// @brief  This class represent a vector of pointers to rows with
///         crescend size
//
/// @remarks
//----------------------------------------------------------------
template < typename AllocByte  >
class pool64_cnc < 0 , AllocByte>
{
public:
//##########################################################################
//                                                                        ##
//     D E F I N I T I O N S    &     S T A T I C _ A S S E R T           ##
//                                                                        ##
//##########################################################################
typedef typename AllocByte::value_type	    value_type; //Element type
static uint64_t const MaskPos = (1ULL << 58)-1 ;
static_assert(sizeof(value_type) == 1,"Error AllocByte");
typedef countertree::alloc::spinlock            spinlock ;

private:
//##########################################################################
//                                                                        ##
//                P R I V A T E        V A R I A B L E S                  ##
//                                                                        ##
//##########################################################################
AllocByte AB ;
void * Ptr;
uint64_t NElem ;
spinlock spl;

//##########################################################################
//                                                                        ##
//                 F O R B I D D E N    F U N C T I O N S                 ##
//                                                                        ##
//  pool64 ( const pool64 &);                                             ##
//  pool64 & operator = ( const pool64 &);                                ##
//                                                                        ##
//##########################################################################
pool64_cnc ( const pool64_cnc &) = delete;
pool64_cnc & operator = ( const pool64_cnc &) = delete;

public:
//##########################################################################
//                                                                        ##
//                P U B L I C      F U N C T I O N S                      ##
//                                                                        ##
//  pool64  ( void)                                                       ##
//  virtual ~pool64 ( void )                                              ##
//                                                                        ##
//  uint64_t     size( void)                                              ##
//  uint64_t     capacity ( void)                                         ##
//  void         clear ( void )                                           ##
//                                                                        ##
//  void * allocate ( void )                                              ##
//  void deallocate ( void *P1)                                           ##
//                                                                        ##
// #if __DEBUG_CNTREE != 0                                                ##
//    bool check( void) const;                                            ##
// #endif                                                                 ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : pool
/// @brief class constructor
/// @remarks
//------------------------------------------------------------------------
explicit pool64_cnc  ( void): NElem(0)
{   //--------------------------- begin -------------------------
    std::unique_lock<spinlock> ul( spl);
    Ptr = AB.allocate(0) ;
} ;

//------------------------------------------------------------------------
//  function : ~pool
/// @brief class destructor
/// @remarks
//------------------------------------------------------------------------
virtual ~pool64_cnc ( void )
{   std::unique_lock<spinlock> ul( spl);
    AB.deallocate (Ptr, 0) ;
};

//------------------------------------------------------------------------
//  function : size
/// @brief return the number of elements allocated by the IncVector
/// @return number of elements allocated
/// @remarks
//------------------------------------------------------------------------
uint64_t size( void )const { return NElem ;};

//------------------------------------------------------------------------
//  function : capacity
/// @brief return the actual capacity of the IncVector
/// @return capacity
/// @remarks
//------------------------------------------------------------------------
uint64_t capacity ( void) const { return MaskPos; };

//------------------------------------------------------------------------
//  function : clear
/// @brief : clean the IncVector
/// @remarks
//------------------------------------------------------------------------
void clear ( void ) { NElem =0;};

//------------------------------------------------------------------------
//  function : allocate
/// @brief Allocate an element from the IncVector
/// @return pointer to the object allocated
/// @remarks
//------------------------------------------------------------------------
void * allocate ( void )
{   //----------------------------------- begin --------------------------
    std::unique_lock<spinlock> ul( spl);
    NElem ++ ;
    return (Ptr) ;
};
//------------------------------------------------------------------------
//  function : deallocate
/// @brief deallocate an object
/// @param [in]
/// @return
/// @remarks
//------------------------------------------------------------------------
void deallocate ( void *P1)
{   //-------------------------------------- begin --------------------------
    std::unique_lock<spinlock> ul( spl);
    if ( P1 == Ptr ) NElem-- ;
    else throw std::bad_alloc();
};
#if __DEBUG_CNTREE != 0
//------------------------------------------------------------------------
//  function : check
/// @brief check if the internal structure of the pool is OK
/// @param [in]
/// @return  true : correct  false: fail
/// @remarks
//------------------------------------------------------------------------
bool check( void) const { return true ;};
#endif

//=========================================================================
};//              E N D     P O O L 6 4     C L A S S
//=========================================================================

#if __DEBUG_CNTREE != 0
template < typename AllocByte >
std::ostream & operator<< ( std::ostream & S , const pool64_cnc<0,AllocByte> & P )
{   //--------------------------------------- begin ------------------------
    S<<"Capacity :"<<P.capacity()<<"  Size :"<<P.size() <<std::endl;
    S<< std::hex<<(void*)(P.Ptr)<<std::dec;
    return S ;
};
#endif
//==========================================================================
};//              E N D    A L L O C     N A M E S P A C E
//==========================================================================

//==========================================================================
};//              E N D    C N T R E E    N A M E S P A C E
//==========================================================================
#endif
