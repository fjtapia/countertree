//----------------------------------------------------------------------------
/// @file suballocator.hpp
/// @brief
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_ALLOC_SUBALLOCATOR_HPP
#define __CNTREE_ALLOC_SUBALLOCATOR_HPP


#include <boost/countertree/alloc/suballocator32.hpp>
#include <boost/countertree/alloc/suballocator64.hpp>
namespace countertree
{
namespace alloc
{
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #      U S I N G    D E C L A R A T I O N S        #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################


//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #       C L A S S E S     F O R   T H E            #             ##
//       #                                                  #             ##
//       #         M E T A P R O G R A M M I N G            #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
template < class T, unsigned NByte  = alloc::NByte>
struct select
{   typedef suballocator32<typename filter_suballoc<T>::name >  my_suballoc ;

};
template < class T>
struct select<T,8>
{   typedef suballocator64 < typename filter_suballoc<T>::name>  my_suballoc ;

};
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #       C L A S S    S U B A L L O C A T O R       #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################

//-------------------------------------------------------------
/// @class  suballocator
/// @brief  This class is a layer, with automatic selection of the suballocator
///         depending of the runtime ( 32 or 64 bits)
/// @remarks
//----------------------------------------------------------------
template <typename T>
class suballocator : public select<T, alloc::NByte>::my_suballoc
{ public:
    //------------------------------------------------------------------------
    // Public definitions
    //------------------------------------------------------------------------
    //typedef typename select<T, alloc::NByte>::my_suballoc::value_type value_type ;

    //------------------------------------------------------------------------
    //  function : suballocator
    /// @brief constructor of the class
    //------------------------------------------------------------------------
    explicit suballocator ( void){ };


    //------------------------------------------------------------------------
    //  function : suballocator
    /// @brief Copy constructor
    /// @param [in] The parameter is not used
    //------------------------------------------------------------------------
    suballocator( typename alloc::select<T, alloc::NByte>::my_suballoc & Alfa) {};

    //------------------------------------------------------------------------
    //  function : suballocator
    /// @brief Copy constructor fron an allocator of other type
    /// @param [in] The parameter is not used
    //------------------------------------------------------------------------
    template<typename U>
    suballocator(suballocator<U> const&) {};

    //------------------------------------------------------------------------
    //  function : ~suballocator
    /// @brief Destructor of the class
    //------------------------------------------------------------------------
    virtual ~suballocator(void){};
}; ;

//########################################################################
};//              E N D    A L L O C     N A M E S P A C E
//########################################################################

//########################################################################
};//              E N D    C N T R E E    N A M E S P A C E
//########################################################################
#endif
