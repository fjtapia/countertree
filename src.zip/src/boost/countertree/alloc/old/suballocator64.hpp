//----------------------------------------------------------------------------
/// @file suballocator64.hpp
/// @brief
///
/// @author Copyright (c) 2010 2012 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __CNTREE_SUBALLOCATOR64_HPP
#define __CNTREE_SUBALLOCATOR64_HPP

#include <boost/countertree/alloc/basic_suballoc64.hpp>
#include <boost/countertree/alloc/filter_suballoc.hpp>
#include <limits>

namespace countertree
{
namespace alloc
{
/*
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                 F O R W A R D                    #             ##
//       #                                                  #             ##
//       #             D E C L A R A T I O N S              #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
template<typename Allocator2 > class suballocator64;
template<typename Allocator2 > class suballocator32;

//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #       C L A S S       F I L T E R 6 4            #             ##
//       #                                                  #             ##
//       #        ( M e t a p r o g r a m m i n g )         #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
template <class Allocator1 >
struct Filter64
{   typedef Allocator1 name ;
};

template <class U >
struct Filter64 < suballocator64< U > >
{   typedef U name ;
};
template <class U >
struct Filter64 < suballocator32< U > >
{   typedef U name ;
};
*/
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                   C L A S S                      #             ##
//       #                                                  #             ##
//       #           S U B A L L O C A T O R 6 4            #             ##
//       #                                                  #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//-------------------------------------------------------------
/// @class suballocator64
///
/// @remarks This class is an allocator with a incremental pool
///          of alogaritmic number of elements
//----------------------------------------------------------------
template<typename Allocator>
class suballocator64 :public root_suballoc <Allocator>,
    public basic_suballoc64 <typename filter_suballoc<Allocator>::name ,
                                    typename Allocator::value_type>
{
public :
//##########################################################################
//                                                                        ##
//       C O N S T R U C T O R , D E S T R U C T O R , B I N D            ##
//                                                                        ##
//  explicit suballocator64();                                            ##
//  suballocator64( suballocator64<Allocator> const&) ;                   ##
//                                                                        ##
//  template<typename U>                                                  ##
//  suballocator64(suballocator64<U> const&) ;                            ##
//                                                                        ##
//  virtual ~suballocator64() ;                                           ##
//                                                                        ##
//  template<typename U>                                                  ##
//  struct rebind                                                         ##
//                                                                        ##
//##########################################################################
typedef typename basic_suballoc64 <typename filter_suballoc<Allocator>::name ,
                                   typename Allocator::value_type>::value_type value_type ;

//------------------------------------------------------------------------
//  function : basic_suballoc64
/// @brief constructor of the class
//------------------------------------------------------------------------
explicit suballocator64(){  };

//------------------------------------------------------------------------
//  function : basic_suballoc64
/// @brief Copy constructor
/// @param [in] The parameter is not used
//------------------------------------------------------------------------
suballocator64( suballocator64<Allocator> const&) {};

//------------------------------------------------------------------------
//  function : basic_suballoc64
/// @brief Copy constructor fron an allocator of other type
/// @param [in] The parameter is not used
//------------------------------------------------------------------------
template<typename U>
suballocator64(suballocator64<U> const&) {};

//------------------------------------------------------------------------
//  function : ~basic_suballoc64
/// @brief Destructor of the class
//------------------------------------------------------------------------
virtual ~suballocator64() { };

//--------------------------------------------------------------------------
//    convert an allocator<T> to allocator<U>
//--------------------------------------------------------------------------
template<typename U>
struct rebind
{   typedef  typename Allocator::template rebind<U>::other base_other ;
    typedef suballocator64 <base_other> other;
};

//##########################################################################
//                                                                        ##
//           B O O L E A N    O P E R A T O R S                           ##
//                                                                        ##
//  bool operator==(suballocator64 const&)                                ##
//  bool operator!=(suballocator64 const& )                               ##
//                                                                        ##
//  template <typename Allocator2>                                        ##
//  bool operator==(suballocator64<Allocator2> const&)                    ##
//                                                                        ##
//  template <typename Allocator2 >                                       ##
//  bool operator!=(suballocator64<Allocator2> const& )                   ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : operator==
/// @brief equality operator
/// @param [in] reference to the suballocator to compare
/// @return always return true
/// @remarks
//------------------------------------------------------------------------
bool operator==(suballocator64 const&)  {  return true;   };

//------------------------------------------------------------------------
//  function : operator !=
/// @brief inequality operator
/// @param [in]reference to the suballocator to compare
/// @return always return false
/// @remarks
//------------------------------------------------------------------------
bool operator!=(suballocator64 const& )  { return false;  };

//------------------------------------------------------------------------
//  function : operator==
/// @brief equality operator
/// @param [in] reference to the suballocator to compare
/// @return always return true
/// @remarks
//------------------------------------------------------------------------
template <typename Allocator2>
bool operator==(suballocator64<Allocator2> const&) { return true;  };

//------------------------------------------------------------------------
//  function : operator !=
/// @brief inequality operator
/// @param [in]reference to the suballocator to compare
/// @return always return false
/// @remarks
//------------------------------------------------------------------------
template <typename Allocator2>
bool operator!=(suballocator64<Allocator2> const& )  { return false; };


//------------------------------------------------------------------------
};//        E N D     S U B A L L O C A T O R 6 4      C L A S S
//------------------------------------------------------------------------

//------------------------------------------------------------------------
};//              E N D    A L L O C     N A M E S P A C E
//------------------------------------------------------------------------

//------------------------------------------------------------------------
};//              E N D    C N T R E E    N A M E S P A C E
///------------------------------------------------------------------------
#endif
